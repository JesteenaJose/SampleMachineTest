//
//  VerificationViewController.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import UIKit

class VerificationViewController: UIViewController ,UITextFieldDelegate{

    // MARK: - IB
     
    // variable for the mobile number
    var mobileNumber = ""
    
    ///UITextField for OTP
    @IBOutlet private weak var OTPTextField: UITextField!
    
    ///error messge for OTP
    @IBOutlet private weak var errorMessageOTPLabel: UILabel!
    
    
    //instance of the PhoneAuthViewModel
    lazy var viewModel: VerificationViewModel = {
        return VerificationViewModel()
    }()
        
    //instance of the PhoneAuthViewModel
    lazy var phoneAuthViewModel: PhoneAuthViewModel = {
        return PhoneAuthViewModel()
    }()
    
    private func initializeViewController() {
        viewModel.fetchOTPDataClosure = { [weak self] successUserData, errorMsg in
            
            if  let error = errorMsg {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type: .invalidOTP, message: "")
                }
            } else {
               //handling the success Scenorio
                
               // UserDefaults.standard.set(verificationId, forKey: "authVerificationID") //setObject
                self?.navigateToCreateViewController()
            }
            
        }
        
        phoneAuthViewModel.fetchPhoneAuthDataClosure = { [weak self] verificationId, errorMsg in
            
            if  let error = errorMsg {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type: .firebaseError, message: "Firebase Error")
                }
            } else {
                
               //handling the success Scenorio
                UserDefaults.standard.set(verificationId, forKey: "authVerificationID") //setObject
            }
            
        }
        
        
        viewModel.errorClosure = { [weak self]  errorType in
            if  let type = errorType {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type:type , message: "")
                }
            }
        }
        
    }
    
    /// to set the textField delegate
    private func setupTextFieldDelegate(){
        OTPTextField.delegate = self
     }
    
    
    /// MARK: - Navigation
    
    private func navigateToCreateViewController() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let verificationViewController = storyBoard.instantiateViewController(withIdentifier: "CreateUserViewController") as! CreateUserViewController
       // verificationViewController.mobileNumber = viewModel.mobileNumber
        self.navigationController?.pushViewController(verificationViewController, animated: true)
    }
    
    func showError(type: ErrorType, message: String) {
        switch type {
        case .emptyOTP , .invalidOTP:
            let msg = getErrorMessage(for: type)
            errorMessageOTPLabel.isHidden = false
            errorMessageOTPLabel.text = "\(msg)"
        case .firebaseError:
            errorMessageOTPLabel.isHidden = false
            errorMessageOTPLabel.text = "\(message)"
        case .emptyMobileNumber , .invalidateMobileNumber:
            break
        case .emptyFirstName, .emptyUserName, .emptyLastName, .emptyEmail , .invalidEmail:
            break

        }
       
    }
    
    private func hideErrorLabel(of type: ErrorType) {
        errorMessageOTPLabel.isHidden = true
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initializeViewController()
        setupTextFieldDelegate()
        // Do any additional setup after loading the view.
    }
    
    
    /// on click of the verify Button
    /// - Parameter sender: <#sender description#>
    @IBAction func onVerifyButtonClick(_ sender: Any) {
        viewModel.vertificationCode = self.OTPTextField.text ?? ""
        viewModel.validateField()
    }
    
    /// on click Resend Buttton
    /// - Parameter sender: <#sender description#>
    @IBAction func onResendOTPButtonClick(_ sender: Any) {
        phoneAuthViewModel.mobileNumber = mobileNumber
        phoneAuthViewModel.verifyPhoneNumber()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        let text = textField.text ?? ""
        switch textField {
        case OTPTextField:
            viewModel.otp = text
        default:
            break
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case OTPTextField:
            hideErrorLabel(of: .emptyOTP)
        default:
            break
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        switch textField {
        case OTPTextField:
            return range.location < 7
        default:
            break
        }
        return true
    }

}
