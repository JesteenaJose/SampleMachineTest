//
//  VerificationViewModel.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import Foundation
import FirebaseAuth

class VerificationViewModel {
    //MARK: - Properties
    
    /// variable used for mobile number
    var otp  = ""

    var vertificationID  = ""

    var vertificationCode = ""

    //Closure for success handling
    var fetchOTPDataClosure: ((_ successData: String,_ errorMessage: Error?) -> Void)?
    
    //Closure for error handling
    var errorClosure: ((_ errorMessage: ErrorType?) -> Void)?
    
    init(){
    }
    
    //MARK:- Helper
    
    //valdiation for the field mobile NUmber
    func validateField() {
        if vertificationCode.isBlank {
            //sending error message
            self.errorClosure?(.emptyOTP)
        } else{
            self.verifyOTP()
            //calling the firebase function
        }
    }
    
    func verifyOTP() {
        
        guard let vertificationID =  UserDefaults.standard.string(forKey: "authVerificationID") else {
            return
        }
            let credential =  PhoneAuthProvider.provider().credential(withVerificationID: vertificationID, verificationCode: vertificationCode)
            Auth.auth().signIn(with: credential, completion: { authData, error in
                if (error != nil) {
                    print(error.debugDescription)
                    self.fetchOTPDataClosure?( "", error)

                } else {
                    print("Authentication success: \(authData?.user.phoneNumber)")
                    self.fetchOTPDataClosure?(authData?.user.phoneNumber ?? "", nil)
                }
                
            })
        
    }
}
