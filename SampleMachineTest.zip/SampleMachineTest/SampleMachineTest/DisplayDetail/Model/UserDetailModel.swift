//
//  AddressModel.swift
//  kompis
//
//  Created by wac on 18/01/23.
//  Copyright © 2023 IKEA. All rights reserved.
//

import Foundation

struct UserDetailModel : Codable {

    let userName : String?
    let firstName : String?
    let lastName : String?
    let email : String?


}
