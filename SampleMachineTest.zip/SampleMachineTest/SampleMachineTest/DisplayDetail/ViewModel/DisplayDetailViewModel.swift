//
//  DisplayDetailViewModel.swift
//  SampleMachineTest
//
//  Created by macbook on 27/06/23.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

class DisplayDetailViewModel {
    //MARK: - Properties
    
    /// variable used for userName
    var userName  = ""

    /// variable used for firstName
    var firstName  = ""

    /// variable used for lastName
    var lastName = ""
    
    /// variable used for email
    var email = ""

    //Closure for success handling
    var fetchUserDetailDataClosure: ((_ responseModel: UserDetailModel, _ successResponse: Bool) -> Void)?
    
    //Closure for error handling
    var errorClosure: ((_ errorMessage: ErrorType?) -> Void)?
    
    init(){
    }
    
    //MARK:- Helper
   
    // display the user details
    func displayUserDetail() {
        
        //retrieve the data fromthe realtime database
        let ref1 = Database.database().reference().child("users")
        ref1.observeSingleEvent(of: .childAdded, with: { (snapshot) in
             if let userDict = snapshot.value as? [String:Any] {
                  //Do not cast print it directly may be score is Int not string
                 guard let userName = userDict["userName"] as? String else { return }
                 guard let firstName = userDict["firstName"] as? String else { return }
                 guard let lastName = userDict["lastName"] as? String else { return }
                 guard let email = userDict["email"]  as? String else { return }

                 let model = UserDetailModel(userName: userName, firstName: firstName, lastName: lastName, email: email)
                 self.fetchUserDetailDataClosure?(model ,true)
             }
        })

    }
}
