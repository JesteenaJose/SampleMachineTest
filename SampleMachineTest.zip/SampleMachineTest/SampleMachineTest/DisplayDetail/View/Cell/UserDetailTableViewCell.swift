//
//  UserDetailTableViewCell.swift
//  SampleMachineTest
//
//  Created by macbook on 27/06/23.
//

import UIKit

class UserDetailTableViewCell: UITableViewCell {

    
    ///UILabel for userName
    @IBOutlet private weak var userNameNameTextField: UILabel!
    
    ///UILabel for firstName
    @IBOutlet private weak var firstNameTextField: UILabel!
    
    ///UILabel for lastName
    @IBOutlet private weak var lastNameTextField: UILabel!
    
    ///UILabel for email
    @IBOutlet private weak var emailTextField: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func configure(model: UserDetailModel) {
        self.userNameNameTextField.text = model.userName
        self.firstNameTextField.text = model.firstName
        self.lastNameTextField.text = model.lastName
        self.emailTextField.text = model.email

    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
