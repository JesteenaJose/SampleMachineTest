//
//  DisplayDetailViewController.swift
//  SampleMachineTest
//
//  Created by macbook on 27/06/23.
//

import UIKit

class DisplayDetailViewController: UIViewController {

    
    ///UILabUITableView
    @IBOutlet private weak var tableview: UITableView!
    
    var userDetailModel: [UserDetailModel]?
    
    private let UserDetailTableViewCell = "UserDetailTableViewCell"

    
    //instance of the PhoneAuthViewModel
    lazy var viewModel: DisplayDetailViewModel = {
        return DisplayDetailViewModel()
    }()
    
    
    /// to set the textField delegate
    private func registerCell(){
        let nibuserDeatail = UINib(nibName: UserDetailTableViewCell, bundle: Bundle.main)
        tableview.register(nibuserDeatail, forCellReuseIdentifier: UserDetailTableViewCell)

     }
    
    private func initializeViewController() {
        viewModel.fetchUserDetailDataClosure = { [weak self] responseData , isSuccess in
            
               //handling the success Scenorio
            self?.userDetailModel = [responseData]
            self?.tableview.reloadData()
            
        }
        
        viewModel.errorClosure = { [weak self]  errorType in
            if  let type = errorType {
                DispatchQueue.main.async {
                    //displaying the error message
                  //  self?.showError(type: type , message: "")
                }
            }
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        registerCell()
        viewModel.displayUserDetail()
        initializeViewController()
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

extension DisplayDetailViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      //  if self.userDetailModel?.count ?? 0 > 0 {
            return self.userDetailModel?.count ?? 0

//        }
//        return 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: UserDetailTableViewCell, for: indexPath) as? UserDetailTableViewCell else { return UITableViewCell() }
        cell.configure(model: (userDetailModel?[indexPath.row])! )
        return cell
    }
    
}


