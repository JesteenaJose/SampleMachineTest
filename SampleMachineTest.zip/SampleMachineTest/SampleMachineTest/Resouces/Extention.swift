//
//  Extention.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import Foundation

extension String {
    var strippedSpecialCharacters: String {
        let okayChars = Set("abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLKMNOPQRSTUVWXYZ1234567890")
        let strippedString = self.filter {okayChars.contains($0)}
        return  strippedString
    }
    
    
    // check empty textfield
    var isBlank: Bool {
        let trimmedText = self.trimWhiteSpaces()
        return trimmedText.isEmpty
    }
    
    // Trim all white space
    func trimWhiteSpaces() -> String {
        return self.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines)
    }
    
    // Validate email id
    
    var isValidEmail:  Bool {
        if isBlank {
            return false
        }
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let emailTest = NSPredicate(format: "SELF MATCHES %@", emailRegex)
        return emailTest.evaluate(with: self)
    } // use as: - "your email".isvalidEmail
    
    // Validate Phone id
    
    var isValidPhone:Bool {
        if isBlank {
            return false
        }
        let phoneRegex = "^[0-9+]{0,1}+[0-9]{5,16}$"
        let phoneTest = NSPredicate(format: "SELF MATCHES %@", phoneRegex)
        return phoneTest.evaluate(with: self)
    }
    
    
    func invalidPassword(_ value: String) -> String?
        {
            if value.count < 8
            {
                return "Password must be at least 8 characters"
            }
            if containsDigit(value)
            {
                return "Password must contain at least 1 digit"
            }
            if containsLowerCase(value)
            {
                return "Password must contain at least 1 lowercase character"
            }
            if containsUpperCase(value)
            {
                return "Password must contain at least 1 uppercase character"
            }
            return nil
        }
        func containsDigit(_ value: String) -> Bool
            {
                let reqularExpression = ".*[0-9]+.*"
                let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
                return !predicate.evaluate(with: value)
            }
            
            func containsLowerCase(_ value: String) -> Bool
            {
                let reqularExpression = ".*[a-z]+.*"
                let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
                return !predicate.evaluate(with: value)
            }
            
            func containsUpperCase(_ value: String) -> Bool
            {
                let reqularExpression = ".*[A-Z]+.*"
                let predicate = NSPredicate(format: "SELF MATCHES %@", reqularExpression)
                return !predicate.evaluate(with: value)
            }
    
}
