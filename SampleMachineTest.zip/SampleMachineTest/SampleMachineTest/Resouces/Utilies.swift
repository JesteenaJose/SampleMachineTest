//
//  Utilies.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import Foundation

// enum case for handle the mobile number
enum ErrorType {
    case emptyMobileNumber,invalidateMobileNumber,emptyOTP,firebaseError,invalidOTP
    case emptyFirstName,emptyUserName,emptyLastName,emptyEmail,invalidEmail

}

enum CreateUserField {
    case firstName,userName,lastName,email
}

func getErrorMessage(for type: ErrorType) -> String{
    switch type {
    case .emptyMobileNumber:
        return "Enter mobile number"
    case .invalidateMobileNumber:
        return "Please enter valid mobile number"
    case .emptyOTP:
        return "Enter OTP"
    case .invalidOTP:
        return "Enter valid OTP"
    case .firebaseError:
        return ""
    case .emptyFirstName:
        return "Enter FirstName"
    case .emptyUserName:
        return "Enter UserName"
    case .emptyLastName:
        return "Enter LastName"
    case .emptyEmail:
        return "Enter Email"
    case .invalidEmail:
        return "Enter valid email address"
    }
}
