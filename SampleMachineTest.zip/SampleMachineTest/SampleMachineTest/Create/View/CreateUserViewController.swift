//
//  CreateUserViewController.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import UIKit

class CreateUserViewController: UIViewController ,UITextFieldDelegate{

    // MARK: - IB
    
    ///UITextField for userName
    @IBOutlet private weak var userNameNameTextField: UITextField!
    
    ///UITextField for firstName
    @IBOutlet private weak var firstNameTextField: UITextField!
    
    ///UITextField for lastName
    @IBOutlet private weak var lastNameTextField: UITextField!
    
    ///UITextField for email
    @IBOutlet private weak var emailTextField: UITextField!
    
    ///UILabel for error message of  FirstName
    @IBOutlet private weak var errorMessageFirstNameLabel: UILabel!
    
    ///UILabel for error message of  UserName
    @IBOutlet private weak var errorMessageUserNameLabel: UILabel!
    
    ///UILabel for error message of  lastName
    @IBOutlet private weak var errorMessageLastNameLabel: UILabel!
    
    ///UILabel for error message of  email
    @IBOutlet private weak var errorMessageEmailLabel: UILabel!
    
    // MARK: - Private methods
    
   fileprivate func addObserver() {
       NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
          NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
  }
    
    //instance of the PhoneAuthViewModel
    lazy var viewModel: CreateViewModel = {
        return CreateViewModel()
    }()
    
   /// to set the textField delegate
   private func setupTextFieldDelegate(){
       firstNameTextField.delegate = self
       lastNameTextField.delegate = self
       userNameNameTextField.delegate = self
       emailTextField.delegate = self

    }
    
    
    /// to set the textField delegate
    private func clearAllTextFiledData(){
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        userNameNameTextField.text = ""
        emailTextField.text = ""

     }
    
    private func initializeViewController() {
        viewModel.fetchCreateUserDetailDataClosure = { [weak self] successResponse in
            
               //handling the success Scenorio
                self?.navigateToDisplayUserDetailViewController()
            
        }
        
        viewModel.errorClosure = { [weak self]  errorType in
            if  let type = errorType {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type: type , message: "")
                }
            }
        }
        
    }
    
    func showError(type: ErrorType, message: String) {
        switch type {
        case .emptyUserName:
            let msg = getErrorMessage(for: type)
            errorMessageUserNameLabel.isHidden = false
            errorMessageUserNameLabel.text = "\(msg)"
        case .emptyFirstName:
            let msg = getErrorMessage(for: type)
            errorMessageFirstNameLabel.isHidden = false
            errorMessageFirstNameLabel.text = "\(msg)"
        case .emptyLastName:
            let msg = getErrorMessage(for: type)
            errorMessageLastNameLabel.isHidden = false
            errorMessageLastNameLabel.text = "\(msg)"
        case .emptyEmail, .invalidEmail:
            let msg = getErrorMessage(for: type)
            errorMessageEmailLabel.isHidden = false
            errorMessageEmailLabel.text = "\(msg)"
        case .emptyMobileNumber ,.invalidateMobileNumber, .emptyOTP, .firebaseError, .invalidOTP:
          break

        }
        
    }
    
    private func hideErrorLabel(of type: ErrorType) {
        switch type {
        case .emptyUserName:
            errorMessageUserNameLabel.isHidden = true
        case .emptyFirstName:
            errorMessageFirstNameLabel.isHidden = true
        case .emptyLastName:
            errorMessageLastNameLabel.isHidden = true
        case .emptyEmail , .invalidEmail:
            errorMessageEmailLabel.isHidden = true
        case .emptyMobileNumber ,.invalidateMobileNumber, .emptyOTP, .firebaseError, .invalidOTP:
            break
            
        }
    }
    /// MARK: - Navigation
    
    private func navigateToDisplayUserDetailViewController() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let verificationViewController = storyBoard.instantiateViewController(withIdentifier: "DisplayDetailViewController") as! DisplayDetailViewController
       // verificationViewController.mobileNumber = viewModel.mobileNumber
        self.navigationController?.pushViewController(verificationViewController, animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addObserver()
        setupTextFieldDelegate()
        initializeViewController()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        clearAllTextFiledData()
    }
    
    @objc  private func keyboardWillShow(notification: NSNotification) {
//        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
////            if self.view.frame.origin.y == 0 {
////                self.view.frame.origin.y -= keyboardSize.height
////            }
//        }

    }

    @objc private func keyboardWillHide(notification: NSNotification) {
//        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
////            if self.view.frame.origin.y != 0 {
////                self.view.frame.origin.y += keyboardSize.height
////            }
//        }
    }
    
    /// MARK: - Navigation
    
    private func navigateToUserDetailViewController() {
      //  let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
      //  let verificationViewController = storyBoard.instantiateViewController(withIdentifier: "VerificationViewController") as! D
       // verificationViewController.mobileNumber = viewModel.mobileNumber
       // self.navigationController?.pushViewController(verificationViewController, animated: true)
    }
    

   ///MARK:- IBAction
    
    @IBAction func onClickCreateButton(_ sender: Any) {
        viewModel.userName = self.userNameNameTextField.text ?? ""
        viewModel.firstName = self.firstNameTextField.text ?? ""
        viewModel.lastName = self.lastNameTextField.text ?? ""
        viewModel.email = self.emailTextField.text ?? ""
        viewModel.validateField()
    }
    
        
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func textFieldDidEndEditing(_ textField: UITextField) {
        let text = textField.text ?? ""
        switch textField {
        case userNameNameTextField:
            viewModel.userName = text
        case firstNameTextField:
            viewModel.firstName = text
        case lastNameTextField:
            viewModel.lastName = text
        case emailTextField:
            viewModel.email = text
        default:
            break
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case userNameNameTextField:
            hideErrorLabel(of: .emptyUserName)
        case firstNameTextField:
            hideErrorLabel(of: .emptyFirstName)
        case lastNameTextField:
            hideErrorLabel(of: .emptyLastName)
        case emailTextField:
            hideErrorLabel(of: .emptyEmail)
        default:
            break
        }
    }

}

