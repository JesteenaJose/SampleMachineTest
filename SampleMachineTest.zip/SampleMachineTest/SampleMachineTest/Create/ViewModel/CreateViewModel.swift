//
//  CreateViewModel.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import Foundation
import FirebaseAuth
import FirebaseDatabase

class CreateViewModel {
    //MARK: - Properties
    
    /// variable used for userName
    var userName  = ""

    /// variable used for firstName
    var firstName  = ""

    /// variable used for lastName
    var lastName = ""
    
    /// variable used for email
    var email = ""

    var createUserDetailCollection = [CreateUserField]()
    
    //Closure for success handling
    var fetchCreateUserDetailDataClosure: ((_ successResponse: Bool) -> Void)?
    
    //Closure for error handling
    var errorClosure: ((_ errorMessage: ErrorType?) -> Void)?
    
    init(){
        createUserDetailCollection = [.userName, .firstName, .lastName, .email]
    }
    
    //MARK:- Helper
    
    //valdiation all field
    func validateField() {
            var isEmpty = false
            createUserDetailCollection.forEach { field in
                let type = getErrorType(for: field)
                if checkIsEmpty(field: field) {
                    self.errorClosure?(type)
                    isEmpty = true
                }
            }
            if !isEmpty {
                if !email.isValidEmail {
                    self.errorClosure?(.invalidEmail)
                }  else {
                    createUser()
                }
            }
    }
                
    
    
    
    /// getErrorType
    /// - Parameter field: FieldType
    /// - Returns: ErrorType
    private func getErrorType(for field: CreateUserField) -> ErrorType {
        switch field {
        case .userName:
            return .emptyUserName
        case .firstName:
            return .emptyFirstName
        case .lastName:
            return .emptyLastName
        case .email:
            return .emptyEmail
       
        }
    }
    
    
    /// checkIsEmpty
    /// - Parameter field: FieldType
    /// - Returns: Bool
    private func checkIsEmpty(field: CreateUserField) -> Bool {
        switch field {
        case .userName:
            return userName.isBlank
        case .firstName:
            return firstName.isBlank
        case .lastName:
            return lastName.isBlank
        case .email:
            return email.isBlank
      
        }
    }

    func createUser() {
        var ref: DatabaseReference!
        ref = Database.database().reference()
        let userID = Auth.auth().currentUser?.uid
        ref.child("users/\(String(describing: userID))/firstName").setValue(firstName)
        ref.child("users/\(String(describing: userID))/userName").setValue(userName)
        ref.child("users/\(String(describing: userID))/lastName").setValue(lastName)
        ref.child("users/\(String(describing: userID))/email").setValue(email)
        self.fetchCreateUserDetailDataClosure?(true)

    }
}
