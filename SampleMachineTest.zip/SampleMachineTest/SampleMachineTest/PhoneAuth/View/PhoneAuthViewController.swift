//
//  PhoneAuthViewController.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import UIKit

class PhoneAuthViewController: UIViewController, UITextFieldDelegate {
    
    // MARK: - IB
    
    ///UITextField for phoneNumber
    @IBOutlet private weak var phoneNumberTextField: UITextField!
    
    ///UILabel for error message of  phoneNumber
    @IBOutlet private weak var errorMessagephoneLabel: UILabel!
    
    
    // MARK: - Private methods
    
   fileprivate func addObserver() {
       NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillShow(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
       NotificationCenter.default.addObserver(self, selector: #selector(keyboardWillHide(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
  }
    
    //instance of the PhoneAuthViewModel
    lazy var viewModel: PhoneAuthViewModel = {
        return PhoneAuthViewModel()
    }()
    
   /// to set the textField delegate
   private func setupTextFieldDelegate(){
       phoneNumberTextField.delegate = self
    }
    
    private func initializeViewController() {
        viewModel.fetchPhoneAuthDataClosure = { [weak self] verificationId, errorMsg in
            
            if  let error = errorMsg {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type: .firebaseError, message: "Firebase Error")
                }
            } else {
                
               //handling the success Scenorio
                UserDefaults.standard.set(verificationId, forKey: "authVerificationID") //setObject
                self?.navigateToOTPViewController()
            }
            
        }
        
        viewModel.errorClosure = { [weak self]  errorMessage in
            if  let errorMsg = errorMessage {
                DispatchQueue.main.async {
                    //displaying the error message
                    self?.showError(type: .invalidateMobileNumber, message: "")
                }
            }
        }
        
    }
    
    func showError(type: ErrorType, message: String) {
        switch type {
        case .emptyMobileNumber, .invalidateMobileNumber:
            let msg = getErrorMessage(for: type)
            errorMessagephoneLabel.isHidden = false
            errorMessagephoneLabel.text = "\(msg)"
        case .firebaseError:
            errorMessagephoneLabel.isHidden = false
            errorMessagephoneLabel.text = "\(message)"
        case .emptyOTP ,. invalidOTP,.emptyFirstName, .emptyUserName, .emptyLastName, .emptyEmail:
            break
      
        case .invalidEmail:
            break
        }
       
    }
    
    private func hideErrorLabel(of type: ErrorType) {
        errorMessagephoneLabel.isHidden = true
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        addObserver()
        setupTextFieldDelegate()
        initializeViewController()
        // Do any additional setup after loading the view.
    }
    
    
    @objc  private func keyboardWillShow(notification: NSNotification) {
//        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
////            if self.view.frame.origin.y == 0 {
////                self.view.frame.origin.y -= keyboardSize.height
////            }
//        }

    }

    @objc private func keyboardWillHide(notification: NSNotification) {
//        if let keyboardSize = (notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? NSValue)?.cgRectValue {
////            if self.view.frame.origin.y != 0 {
////                self.view.frame.origin.y += keyboardSize.height
////            }
//        }
    }
    
    /// MARK: - Navigation
    
    private func navigateToOTPViewController() {
        let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        let verificationViewController = storyBoard.instantiateViewController(withIdentifier: "VerificationViewController") as! VerificationViewController
        verificationViewController.mobileNumber = viewModel.mobileNumber
        self.navigationController?.pushViewController(verificationViewController, animated: true)
    }
    

   ///MARK:- IBAction
    
    @IBAction func onClickSendOTPButton(_ sender: Any) {
        viewModel.mobileNumber = "+91" + (phoneNumberTextField.text ?? "")
        viewModel.validateField()
    }
    
        
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    func textFieldDidEndEditing(_ textField: UITextField) {
        let text = textField.text ?? ""
        switch textField {
        case phoneNumberTextField:
            viewModel.mobileNumber = text
        default:
            break
        }
    }

    func textFieldDidBeginEditing(_ textField: UITextField) {
        switch textField {
        case phoneNumberTextField:
            hideErrorLabel(of: .emptyMobileNumber)
        default:
            break
        }
    }

    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        switch textField {
        case phoneNumberTextField:
            return range.location < 10
        default:
            break
        }
        return true
    }
    
}
