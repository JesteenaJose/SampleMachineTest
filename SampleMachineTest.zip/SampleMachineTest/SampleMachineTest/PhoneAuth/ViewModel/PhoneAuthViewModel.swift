//
//  PhoneAuthViewModel.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import Foundation
import FirebaseAuth

class PhoneAuthViewModel {
    //MARK: - Properties
    
    /// variable used for mobile number
    var mobileNumber  = ""

    //Closure for success handling
    var fetchPhoneAuthDataClosure: ((_ currentVerificationId: String,_ errorMessage: Error?) -> Void)?
    
    //Closure for error handling
    var errorClosure: ((_ errorMessage: ErrorType?) -> Void)?
    
    init(){
    }
    
    //MARK:- Helper
    
    //valdiation for the field mobile NUmber
    func validateField() {
        if mobileNumber.isBlank {
            //sending error message
            self.errorClosure?(.emptyMobileNumber)
        }
//        else if !mobileNumber.isValidPhone {
//            //sending error message
//            self.errorClosure?(.invalidateMobileNumber)
//        }
        
        else{
            //calling the firebase function
            self.verifyPhoneNumber()
        }
    }
    
    func verifyPhoneNumber() {
        Auth.auth().languageCode = "en"
        let phoneNumber = mobileNumber

        Auth.auth().settings?.isAppVerificationDisabledForTesting = false
        // Step 4: Request SMS
        PhoneAuthProvider.provider().verifyPhoneNumber(phoneNumber, uiDelegate: nil) { (verificationID, error) in
            if let error = error {
                print(error.localizedDescription)
                self.fetchPhoneAuthDataClosure?("", error)
                return
            }
            
            // Either received APNs or user has passed the reCAPTCHA
            // Step 5: Verification ID is saved for later use for verifying OTP with phone number
            self.fetchPhoneAuthDataClosure?(verificationID ?? "", error)
        }
    }
}
