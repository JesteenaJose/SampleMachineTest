//
//  ViewController.swift
//  SampleMachineTest
//
//  Created by macbook on 26/06/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

